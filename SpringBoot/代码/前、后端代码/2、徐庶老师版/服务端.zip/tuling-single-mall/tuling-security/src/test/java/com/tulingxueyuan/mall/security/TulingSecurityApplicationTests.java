package com.tulingxueyuan.mall.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TulingSecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
