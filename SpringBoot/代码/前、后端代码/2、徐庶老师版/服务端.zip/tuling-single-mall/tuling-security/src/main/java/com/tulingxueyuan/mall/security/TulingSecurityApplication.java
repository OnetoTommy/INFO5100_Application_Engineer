package com.tulingxueyuan.mall.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TulingSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(TulingSecurityApplication.class, args);
    }

}
