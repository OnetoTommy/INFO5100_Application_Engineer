package com.tulingxueyuan.mall.modules.pms.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 商品审核记录 前端控制器
 * </p>
 *
 * @author XuShu
 * @since 2021-02-26
 */
@RestController
@RequestMapping("/pms/pmsProductVertifyRecord")
public class PmsProductVertifyRecordController {

}

