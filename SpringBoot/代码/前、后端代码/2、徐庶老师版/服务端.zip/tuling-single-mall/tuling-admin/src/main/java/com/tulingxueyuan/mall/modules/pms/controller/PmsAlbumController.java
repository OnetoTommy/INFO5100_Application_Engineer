package com.tulingxueyuan.mall.modules.pms.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 相册表 前端控制器
 * </p>
 *
 * @author XuShu
 * @since 2021-02-26
 */
@RestController
@RequestMapping("/pms/pmsAlbum")
public class PmsAlbumController {
    //
}

