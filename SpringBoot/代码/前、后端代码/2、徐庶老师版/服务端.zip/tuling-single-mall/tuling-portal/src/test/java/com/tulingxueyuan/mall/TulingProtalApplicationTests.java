package com.tulingxueyuan.mall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TulingProtalApplicationTests {

    @Test
    void contextLoads() {
    }

}
