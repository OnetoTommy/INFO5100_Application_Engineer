package com.tulingxueyuan.mall.modules.oms.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 订单表 前端控制器
 * </p>
 *
 * @author XuShu
 * @since 2021-03-21
 */
@RestController
@RequestMapping("/oms/omsOrder")
public class OmsOrderController {

}

