package com.tulingxueyuan.mall.modules.sms.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author XuShu
 * @since 2021-03-16
 */
@RestController
@RequestMapping("/sms/smsHomeCategory")
public class SmsHomeCategoryController {

}

