package com.tulingxueyuan.mall.modules.pms.service;

import com.tulingxueyuan.mall.modules.pms.model.PmsAlbum;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 相册表 服务类
 * </p>
 *
 * @author XuShu
 * @since 2021-03-14
 */
public interface PmsAlbumService extends IService<PmsAlbum> {

}
