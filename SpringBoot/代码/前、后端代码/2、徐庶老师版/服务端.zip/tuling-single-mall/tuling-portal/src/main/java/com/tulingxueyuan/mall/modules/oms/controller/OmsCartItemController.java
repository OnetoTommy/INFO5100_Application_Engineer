package com.tulingxueyuan.mall.modules.oms.controller;


import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * <p>
 * 购物车表 前端控制器
 * </p>
 *
 * @author XuShu
 * @since 2021-03-19
 */
@RestController
@RequestMapping("/oms/omsCartItem")
public class OmsCartItemController {

}

