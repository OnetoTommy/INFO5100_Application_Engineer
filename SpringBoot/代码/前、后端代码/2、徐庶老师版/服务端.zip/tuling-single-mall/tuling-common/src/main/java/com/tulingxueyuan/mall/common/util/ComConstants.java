package com.tulingxueyuan.mall.common.util;

public class ComConstants {
    // 后台 登录session key
    public static final String FLAG_CURRENT_USER = "currentUser";

    // 前台用户session
    public static final String FLAG_MEMEBER_USER = "memberUser";
}
