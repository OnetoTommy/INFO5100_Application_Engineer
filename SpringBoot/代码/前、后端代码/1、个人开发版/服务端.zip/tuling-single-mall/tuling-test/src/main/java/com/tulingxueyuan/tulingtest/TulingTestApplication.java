package com.tulingxueyuan.tulingtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TulingTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(TulingTestApplication.class, args);
    }

}
