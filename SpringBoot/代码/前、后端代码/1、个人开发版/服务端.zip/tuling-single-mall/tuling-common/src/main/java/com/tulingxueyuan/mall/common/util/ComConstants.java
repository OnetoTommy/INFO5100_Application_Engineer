package com.tulingxueyuan.mall.common.util;

public class ComConstants {
    // 登录session key
    public static final String FLAG_CURRENT_USER = "currentUser";
}
