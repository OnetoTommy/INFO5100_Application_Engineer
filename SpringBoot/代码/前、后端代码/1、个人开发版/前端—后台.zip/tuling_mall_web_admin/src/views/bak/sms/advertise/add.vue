<template> 
  <home-advertise-detail :isEdit="false"></home-advertise-detail>
</template>
<script>
  import HomeAdvertiseDetail from './components/HomeAdvertiseDetail'
  export default {
    name: 'addHomeAdvertise',
    components: { HomeAdvertiseDetail }
  }
</script>
<style></style>


